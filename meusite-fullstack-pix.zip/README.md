
# MeuSite (Fullstack) — Express + SQLite + JWT + PIX (demo)

Este projeto contém **frontend** estático e **backend** em Node.js.
- Autenticação com JWT (bcrypt).
- Downloads protegidos (rota que exige token).
- Checkout PIX **de demonstração** (QR + "copia e cola" simplificados). Para produção, use o PSP oficial.

## Como rodar

### 1) Backend
```bash
cd backend
cp .env.example .env   # edite as variáveis
npm install
npm start
```
O backend sobe em `http://localhost:3000`.

### 2) Frontend
Abra `frontend/index.html` no navegador, **ou** sirva com qualquer HTTP server.
Se hospedar separado, salve no navegador a base da API:
```js
localStorage.setItem("api_base", "https://SEU_BACKEND");
```

## Endpoints principais
- POST `/api/register` { name, email, password }
- POST `/api/login` { email, password } -> { token }
- GET `/api/me` (Auth)
- GET `/api/downloads` (Auth)
- GET `/api/downloads/:id/file` (Auth)
- POST `/api/pix/checkout` (Auth) { amount, description } -> { txid, qrCodeDataURL, copiaCola }
- POST `/api/pix/confirm` (Auth) { txid }  # simula confirmação

## Importante sobre PIX
O payload do PIX neste projeto é **apenas para demonstração** e não segue integralmente o padrão BR Code (EMV).  
Para receber pagamentos reais, integre com um **PSP** (ex.: Gerencianet, Mercado Pago, Iugu, Asaas, Pagar.me etc.).
Esses provedores fornecem API para gerar QR dinâmico, consultar status e webhooks.

## Downloads de exemplo
Os arquivos ficam em `backend/downloads/*.txt`. Substitua pelos seus arquivos reais (exe, apk, pdf...).

## Dica de deploy rápido
- Backend: **Render**, **Railway**, **Fly.io** ou **VPS**.
- Frontend: **Netlify**, **Vercel**, **GitHub Pages**.
Lembre de configurar `localStorage.setItem("api_base", "URL_DO_SEU_BACKEND")` no navegador para apontar o frontend ao backend.
