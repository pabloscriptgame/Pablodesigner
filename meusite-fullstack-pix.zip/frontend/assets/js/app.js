
(function(){
  const API_BASE = localStorage.getItem("api_base") || "http://localhost:3000";
  const $ = (s, c=document)=>c.querySelector(s);
  const $$ = (s, c=document)=>Array.from(c.querySelectorAll(s));
  const tokenKey = "meusite.token";

  function setYear(){ const y=$("#year"); if(y) y.textContent=new Date().getFullYear(); }
  function token(){ return localStorage.getItem(tokenKey); }
  function setToken(t){ if(t){localStorage.setItem(tokenKey,t);}else{localStorage.removeItem(tokenKey);} }

  function authHeaders(){
    const t = token();
    return t ? { "Authorization": "Bearer " + t } : {};
  }

  function refreshNavbar(){
    const t = token();
    $("#loginLink")?.classList.toggle("hide", !!t);
    $("#registerLink")?.classList.toggle("hide", !!t);
    $("#dashboardLink")?.classList.toggle("hide", !t);
  }

  function protectRoutes(){
    const page = location.pathname.split("/").pop();
    const protectedPages = ["downloads.html", "dashboard.html"];
    if (protectedPages.includes(page) && !token()){
      alert("Você precisa estar logado.");
      location.href = "login.html";
    }
  }

  function bindRegister(){
    const form=$("#registerForm"); if(!form) return;
    form.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const fd=new FormData(form);
      const body={ name:fd.get("name"), email:String(fd.get("email")).toLowerCase(), password:fd.get("password") };
      const res=await fetch(API_BASE+"/api/register",{method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(body)});
      const data=await res.json();
      if(!res.ok){ alert(data.message||"Erro"); return; }
      alert("Conta criada! Faça login.");
      location.href="login.html";
    });
  }

  function bindLogin(){
    const form=$("#loginForm"); if(!form) return;
    form.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const fd=new FormData(form);
      const body={ email:String(fd.get("email")).toLowerCase(), password:fd.get("password") };
      const res=await fetch(API_BASE+"/api/login",{method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(body)});
      const data=await res.json();
      if(!res.ok){ alert(data.message||"Erro"); return; }
      setToken(data.token);
      alert("Login realizado!");
      location.href="dashboard.html";
    });
  }

  async function fillDashboard(){
    const nameEl=$("#userName"), emailEl=$("#userEmail");
    if(!nameEl||!emailEl) return;
    const res=await fetch(API_BASE+"/api/me",{headers:authHeaders()});
    if(res.ok){
      const me=await res.json();
      nameEl.textContent=me.name; emailEl.textContent=me.email;
      $("#logoutBtn")?.addEventListener("click",()=>{ setToken(null); location.href="index.html"; });
    }else{
      setToken(null); location.href="login.html";
    }
  }

  async function loadDownloads(){
    const wrap=$("#downloads"); if(!wrap) return;
    const res=await fetch(API_BASE+"/api/downloads",{headers:authHeaders()});
    if(!res.ok){ wrap.innerHTML="<p>Erro ao carregar.</p>"; return; }
    const items=await res.json();
    wrap.innerHTML = items.map(it=>`
      <article class="card" style="grid-column:span 12;">
        <h3>${it.name}</h3>
        <p>${it.description} • ${it.size}</p>
        <a class="btn primary" href="${API_BASE}/api/downloads/${it.id}/file" target="_blank" rel="noopener">Baixar</a>
      </article>`).join("");
  }

  function bindPix(){
    const form=$("#pixForm"); if(!form) return;
    const area=$("#pixArea"), qr=$("#pixQr"), copy=$("#pixCopy"), status=$("#pixStatus");
    let txid=null;
    form.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const fd=new FormData(form);
      const body={ amount:Number(fd.get("amount")), description:fd.get("description")||"Pagamento" };
      const res=await fetch(API_BASE+"/api/pix/checkout",{method:"POST", headers:{ "Content-Type":"application/json", ...authHeaders() }, body:JSON.stringify(body)});
      const data=await res.json();
      if(!res.ok){ alert(data.message||"Erro no PIX"); return; }
      txid=data.txid; qr.src=data.qrCodeDataURL; copy.textContent=data.copiaCola; area.classList.remove("hide"); status.textContent="Status: aguardando (demo)";
    });
    $("#markPaid")?.addEventListener("click", async ()=>{
      if(!txid) return;
      const res=await fetch(API_BASE+"/api/pix/confirm",{method:"POST", headers:{ "Content-Type":"application/json", ...authHeaders() }, body:JSON.stringify({txid})});
      const data=await res.json();
      if(res.ok){ status.textContent="Status: pago ✅ (demo)"; } else { alert(data.message||"Falha ao confirmar"); }
    });
  }

  // init
  setYear();
  refreshNavbar();
  protectRoutes();
  bindRegister();
  bindLogin();
  fillDashboard();
  loadDownloads();
  bindPix();
})();