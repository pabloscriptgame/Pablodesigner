
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import QRCode from 'qrcode';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const PORT = process.env.PORT || 3000;
const PIX_KEY = process.env.PIX_KEY || 'sua-chave-pix@exemplo.com';
const PIX_NAME = process.env.PIX_NAME || 'MeuSite Ltda';
const PIX_CITY = process.env.PIX_CITY || 'SAO PAULO';

// DB setup
const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.prepare(`CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  txid TEXT UNIQUE NOT NULL,
  amount_cents INTEGER NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
)`).run();

// Seed sample downloads
const downloads = [
  { id: 1, name: 'App Windows', description: 'Versão 1.0.0', size: '25 MB', file: 'app-windows-demo.txt' },
  { id: 2, name: 'App Android (APK)', description: 'Versão 1.0.0', size: '18 MB', file: 'app-android-demo.txt' },
  { id: 3, name: 'Manual PDF', description: 'Guia do usuário', size: '2 MB', file: 'manual-demo.txt' },
];
app.locals.downloads = downloads;

// Utilities
function auth(req, res, next){
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : null;
  if(!t) return res.status(401).json({message:'Sem token'});
  try{
    const payload = jwt.verify(t, JWT_SECRET);
    req.user = payload;
    next();
  }catch(err){
    return res.status(401).json({message:'Token inválido'});
  }
}

function userByEmail(email){
  return db.prepare('SELECT * FROM users WHERE email = ?').get(email);
}

// Routes
app.get('/', (_req,res)=>res.json({ok:true, service:'MeuSite backend'}));

app.post('/api/register', async (req,res)=>{
  const { name, email, password } = req.body || {};
  if(!name || !email || !password) return res.status(400).json({message:'Campos obrigatórios'});
  if (String(password).length < 6) return res.status(400).json({message:'Senha muito curta'});
  if (userByEmail(email)) return res.status(409).json({message:'E-mail já cadastrado'});
  const hash = bcrypt.hashSync(String(password), 10);
  db.prepare('INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)')
    .run(name, String(email).toLowerCase(), hash, new Date().toISOString());
  return res.json({message:'OK'});
});

app.post('/api/login', (req,res)=>{
  const { email, password } = req.body || {};
  const u = userByEmail(String(email).toLowerCase());
  if(!u) return res.status(404).json({message:'Usuário não encontrado'});
  if(!bcrypt.compareSync(String(password), u.password_hash)) return res.status(401).json({message:'Senha incorreta'});
  const token = jwt.sign({ id:u.id, name:u.name, email:u.email }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({ token });
});

app.get('/api/me', auth, (req,res)=>{
  const u = db.prepare('SELECT id,name,email,created_at FROM users WHERE id=?').get(req.user.id);
  return res.json(u);
});

app.get('/api/downloads', auth, (_req,res)=>{
  res.json(app.locals.downloads);
});

app.get('/api/downloads/:id/file', auth, (req,res)=>{
  const item = app.locals.downloads.find(d=> String(d.id) === String(req.params.id));
  if(!item) return res.status(404).json({message:'Arquivo não encontrado'});
  const filePath = path.join(__dirname, 'downloads', item.file);
  res.download(filePath, item.file);
});

// --- PIX (DEMO) ---
// Gera QR e "copia e cola" não-oficiais para demonstração.
function buildPixPayload({txid, amount}){
  // ATENÇÃO: Este payload é simplificado para DEMO e NÃO segue o padrão BR Code EMV.
  // Em produção, integre com seu PSP (ex.: Gerencianet, Mercado Pago, IUGU etc.) para gerar QR dinâmico.
  const payload = `PIX|key=${PIX_KEY}|name=${PIX_NAME}|city=${PIX_CITY}|txid=${txid}|amount=${amount.toFixed(2)}`;
  return payload;
}

app.post('/api/pix/checkout', auth, async (req,res)=>{
  const amount = Number(req.body?.amount || 0);
  const description = String(req.body?.description || 'Pagamento');
  if(!(amount>0)) return res.status(400).json({message:'Valor inválido'});
  const txid = 'TX' + Date.now().toString(36);
  const amount_cents = Math.round(amount*100);
  db.prepare('INSERT INTO orders(user_id, txid, amount_cents, description, status, created_at) VALUES(?,?,?,?,?,?)')
    .run(req.user.id, txid, amount_cents, description, 'pending', new Date().toISOString());
  const copiaCola = buildPixPayload({txid, amount});
  const qrCodeDataURL = await QRCode.toDataURL(copiaCola);
  return res.json({ txid, copiaCola, qrCodeDataURL, status: 'pending' });
});

app.post('/api/pix/confirm', auth, (req,res)=>{
  const { txid } = req.body || {};
  const order = db.prepare('SELECT * FROM orders WHERE txid=? AND user_id=?').get(txid, req.user.id);
  if(!order) return res.status(404).json({message:'Pedido não encontrado'});
  if(order.status === 'paid') return res.json({message:'Já confirmado'});
  db.prepare('UPDATE orders SET status=? WHERE id=?').run('paid', order.id);
  return res.json({message:'Pagamento confirmado (demo)'});
});

// Static files for test
app.use('/public', express.static(path.join(__dirname, 'downloads')));

app.listen(PORT, ()=>{
  console.log(`API on http://localhost:${PORT}`);
});
